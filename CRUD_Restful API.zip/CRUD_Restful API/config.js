module.exports = {

    url: 'mongodb://localhost:27017/studentdb',

    serverport: 3000 

}